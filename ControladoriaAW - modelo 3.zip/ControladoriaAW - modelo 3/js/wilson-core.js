    // ==========================================================================
    // WILSON CORE 2.0 - FULL FUNCTIONALITY & LOGIC
    // ==========================================================================

    // --- UTILS & NOTIFICATIONS ---
    let globalAudioCtx = null;
    if ("Notification" in window) {
        if (Notification.permission !== "granted" && Notification.permission !== "denied") Notification.requestPermission();
    }
    document.addEventListener('click', function unlockAudio() {
        if (!globalAudioCtx) {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            if (AudioContext) {
                globalAudioCtx = new AudioContext();
                const osc = globalAudioCtx.createOscillator(); const gain = globalAudioCtx.createGain();
                gain.gain.value = 0; osc.connect(gain); gain.connect(globalAudioCtx.destination);
                osc.start(0); osc.stop(0.1);
            }
        }
        document.removeEventListener('click', unlockAudio);
    });
    function playBeep() {
        try {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            if (!AudioContext) return;
            let ctx = globalAudioCtx;
            if (!ctx || ctx.state === 'closed') { ctx = new AudioContext(); globalAudioCtx = ctx; } else if (ctx.state === 'suspended') ctx.resume();
            const osc = ctx.createOscillator(); const gain = ctx.createGain();
            osc.connect(gain); gain.connect(ctx.destination);
            osc.type = 'sine'; osc.frequency.value = 550; 
            const now = ctx.currentTime; gain.gain.setValueAtTime(0, now); gain.gain.linearRampToValueAtTime(0.3, now + 0.1); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.8);
            osc.start(now); osc.stop(now + 0.8);
        } catch (e) { console.warn("Audio blocked:", e); }
    }
    function sendSystemNotification(title, body, targetView, targetId) {
        playBeep();
        if (!("Notification" in window)) return;
        if (Notification.permission === "granted") createVisualNotification(title, body, targetView, targetId);
    }
    function createVisualNotification(title, body, targetView, targetId) {
        try {
            const notif = new Notification(title, { body: body, icon: '/img/logo-sf.png' });
            notif.onclick = function() { window.focus(); if (targetView) navTo(targetView); if (targetId && targetView === 'mapas') loadMap(targetId); this.close(); };
        } catch (e) { console.error("Notif error", e); }
    }

    // --- DATA ---
    let patioData = JSON.parse(localStorage.getItem('aw_caminhoes_v2')) || [];
    let mapData = JSON.parse(localStorage.getItem('mapas_cegos_v3')) || [];
    let mpData = JSON.parse(localStorage.getItem('aw_materia_prima')) || [];
    let carregamentoData = JSON.parse(localStorage.getItem('aw_carregamento')) || [];
    let requests = JSON.parse(localStorage.getItem('aw_requests')) || [];
    let usersData = JSON.parse(localStorage.getItem('mapa_cego_users')) || [];

    let tmpItems = [];
    let currentMapId = null;
    let contextMapId = null; let contextMPId = null; let contextCarrId = null; let contextTruckId = null; 
    let editTmpItems = []; let isEditingMode = false;
    let filteredReportData = []; let currentReportType = '';
    let selectedReportItems = new Set();
    const defaultProducts = ["CX PAP 125A", "AÇ CRISTAL", "AÇ LIQUIDO", "AÇ REFINADO", "SAL REFINADO"];
    const today = new Date().toISOString().split('T')[0];

    function initRoleBasedUI() {
        if(localStorage.getItem('aw_dark_mode') === 'true') {
            document.body.classList.add('dark-mode');
            const tg = document.getElementById('darkModeToggle'); if(tg) tg.checked = true;
        }
        // Roles Visibility
        if (isConferente) {
            const fab = document.getElementById('fabAddTruck'); if(fab) fab.style.display = 'none';
            const mc = document.getElementById('menuCarregamento'); if(mc) mc.style.display = 'none';
        } else {
            const fab = document.getElementById('fabAddTruck'); if(fab) fab.style.display = 'flex';
            const mc = document.getElementById('menuCarregamento'); if(mc) mc.style.display = 'flex';
        }
        const mmp = document.getElementById('menuMateriaPrima');
        if(mmp) mmp.style.display = isRecebimento ? 'flex' : 'none';

        if (isConferente && userSubType) {
            const cA = document.getElementById('col-ALM'); const cG = document.getElementById('col-GAVA'); const cO = document.getElementById('col-OUT');
            if(cA) cA.style.display = 'none'; if(cG) cG.style.display = 'none'; if(cO) cO.style.display = 'none';
            if (userSubType === 'ALM') { if(cA) cA.style.display = 'flex'; if(cG) cG.style.display = 'flex'; }
            else if (userSubType === 'GAVA') { if(cG) cG.style.display = 'flex'; }
            else { 
                if(cO) cO.style.display = 'flex'; 
                const sn = {'INFRA':'INFRAESTRUTURA','MANUT':'MANUTENÇÃO','LAB':'LABORATÓRIO','PESAGEM':'PESAGEM','SST':'SST','CD':'CD','COMPRAS':'COMPRAS'};
                const tit = cO.querySelector('.col-header');
                if(tit && sn[userSubType]) tit.innerHTML = sn[userSubType] + ' <span id="count-OUT">0</span>';
            }
        }
        // Set default dates
        ['patioDateFilter','mapDate','mpDateFilter','carrDateFilter','mapListDateFilter','repDateStart','repDateEnd'].forEach(id=>{
            const el = document.getElementById(id); if(el) el.value = today;
        });
        setInterval(()=>{ const el=document.getElementById('serverTime'); if(el) el.textContent=new Date().toLocaleTimeString(); }, 1000);
    }

    // --- NAV ---
    function toggleMobileMenu() { document.querySelector('.main-sidebar').classList.toggle('show-mobile'); }
    function toggleMapListMobile() { document.getElementById('mobileMapList').classList.toggle('open'); }

    function navTo(view, el) {
        document.querySelectorAll('.view-section').forEach(v => v.classList.remove('active'));
        const t = document.getElementById('view-' + view); if(t) t.classList.add('active');
        document.querySelectorAll('.menu-item').forEach(m => m.classList.remove('active'));
        if (el) el.classList.add('active');
        else { const link = document.querySelector(`.menu-item[onclick*="'${view}'"]`); if(link) link.classList.add('active'); }
        
        document.querySelector('.main-sidebar').classList.remove('show-mobile');
        const titles = { patio:'Controle de Pátio', mapas:'Mapas Cegos', relatorios:'Relatórios', notificacoes:'Notificações', 'materia-prima':'Matéria Prima', 'carregamento':'Carregamento', 'configuracoes':'Configurações', 'perfil': 'Área do Usuário' };
        const pt = document.getElementById('pageTitle'); if(pt) pt.textContent = titles[view] || 'Sistema';
        
        if (view === 'patio') renderPatio();
        if (view === 'mapas') { renderMapList(); if (mapData.length > 0 && !currentMapId) loadMap(mapData[mapData.length - 1].id); }
        if (view === 'materia-prima') renderMateriaPrima();
        if (view === 'carregamento') renderCarregamento();
        if (view === 'notificacoes') renderRequests();
        if (view === 'perfil') renderProfileArea();
        if (view === 'configuracoes') updatePermissionStatus();

        localStorage.setItem('aw_last_view', view);
    }
    function logout() { sessionStorage.removeItem('loggedInUser'); window.location.href = 'login.html'; }

    // --- PROFILE & ADMIN LOGIC ---
    function renderProfileArea() {
        const container = document.getElementById('profileContent');
        container.innerHTML = '';

        if (isAdmin) {
            // ADMIN VIEW
            container.innerHTML = `
                <div class="settings-card">
                    <h4><i class="fas fa-users-cog"></i> Gerenciamento de Usuários (Administrador)</h4>
                    <div style="margin-bottom:20px; background:var(--bg-input); padding:15px; border-radius:6px; border:1px solid var(--border-color);">
                        <h5>Adicionar Novo Usuário</h5>
                        <div style="display:grid; grid-template-columns: 1fr 1fr 1fr 1fr auto; gap:10px; align-items:end;">
                            <div><label style="font-size:0.8rem">Usuário</label><input type="text" id="newUsername" placeholder="Ex: Joao"></div>
                            <div><label style="font-size:0.8rem">Senha</label><input type="text" id="newPassword" placeholder="***"></div>
                            <div><label style="font-size:0.8rem">Função</label>
                                <select id="newRole">
                                    <option value="user">Usuário</option>
                                    <option value="admin">Administrador</option>
                                </select>
                            </div>
                            <div><label style="font-size:0.8rem">Setor/Subtipo</label>
                                <select id="newSector">
                                    <option value="recebimento">Recebimento</option>
                                    <option value="conferente">Conferente (Geral)</option>
                                    <option value="ALM">Conferente ALM</option>
                                    <option value="GAVA">Conferente GAVA</option>
                                    <option value="INFRA">Conferente INFRA</option>
                                    <option value="MANUT">Conferente MANUT</option>
                                </select>
                            </div>
                            <button class="btn btn-save" onclick="addNewUser()">Adicionar</button>
                        </div>
                    </div>
                    <table class="modern-table">
                        <thead><tr><th>Usuário</th><th>Função</th><th>Setor/Subtipo</th><th>Ações</th></tr></thead>
                        <tbody id="adminUserList"></tbody>
                    </table>
                </div>
            `;
            renderUserList();
        } else {
            // USER VIEW
            const countToday = patioData.filter(x => x.chegada.startsWith(today)).length;
            container.innerHTML = `
                <div class="settings-grid">
                    <div class="settings-card">
                        <h4><i class="fas fa-id-card"></i> Meu Perfil</h4>
                        <p><b>Usuário:</b> ${loggedUser.username}</p>
                        <p><b>Função:</b> ${loggedUser.role}</p>
                        <p><b>Setor:</b> ${loggedUser.sector} ${loggedUser.subType ? '('+loggedUser.subType+')' : ''}</p>
                    </div>
                    <div class="settings-card">
                        <h4><i class="fas fa-chart-bar"></i> Estatísticas Hoje</h4>
                        <p>Caminhões no Pátio: <b>${patioData.filter(x=>x.status!=='SAIU').length}</b></p>
                        <p>Entradas Totais: <b>${countToday}</b></p>
                    </div>
                </div>
            `;
        }
    }

    function renderUserList() {
        const tbody = document.getElementById('adminUserList');
        tbody.innerHTML = '';
        usersData.forEach(u => {
            const isMe = u.username === loggedUser.username;
            const btn = isMe ? '<span style="color:#999; font-size:0.8rem;">(Você)</span>' : `<button class="btn btn-edit btn-small" onclick="removeUser('${u.username}')" style="color:red; border-color:red;">Remover</button>`;
            let secDisplay = u.sector; if(u.subType) secDisplay += ` (${u.subType})`;
            tbody.innerHTML += `<tr><td><b>${u.username}</b></td><td><span class="sector-tag" style="background:${u.role==='admin'?'#333':'#1e293b'}">${u.role.toUpperCase()}</span></td><td>${secDisplay}</td><td>${btn}</td></tr>`;
        });
    }

    function addNewUser() {
        const u = document.getElementById('newUsername').value;
        const p = document.getElementById('newPassword').value;
        const r = document.getElementById('newRole').value;
        const sRaw = document.getElementById('newSector').value;

        if(!u || !p) return alert("Preencha usuário e senha.");
        if(usersData.find(x => x.username.toLowerCase() === u.toLowerCase())) return alert("Usuário já existe.");

        let sector = 'recebimento';
        let subType = null;
        if (sRaw === 'recebimento') { sector = 'recebimento'; }
        else if (sRaw === 'conferente') { sector = 'conferente'; subType = null; }
        else { sector = 'conferente'; subType = sRaw; }

        usersData.push({ username: u, password: p, role: r, sector: sector, subType: subType });
        localStorage.setItem('mapa_cego_users', JSON.stringify(usersData));
        renderUserList();
        document.getElementById('newUsername').value = ''; document.getElementById('newPassword').value = ''; alert("Usuário criado.");
    }

    function removeUser(username) {
        if(confirm(`Remover usuário "${username}"?`)) {
            usersData = usersData.filter(x => x.username !== username);
            localStorage.setItem('mapa_cego_users', JSON.stringify(usersData));
            renderUserList();
        }
    }

    // --- TRUCK & PATIO ---
    function modalTruckOpen() {
        tmpItems = []; document.getElementById('tmpList').innerHTML = '';
        document.getElementById('addPlaca').value = ''; document.getElementById('addEmpresa').value = '';
        document.getElementById('chkBalan').checked = false; document.getElementById('chkLaudo').checked = false;
        document.getElementById('modalTruck').style.display = 'flex';
    }
    function openProdSelect() {
        const l = document.getElementById('prodList'); l.innerHTML = '';
        defaultProducts.forEach(p => { l.innerHTML += `<div style="padding:10px; border-bottom:1px solid #eee; cursor:pointer;" onclick="selectProd('${p}')">${p}</div>`; });
        document.getElementById('modalProductSelect').style.display = 'flex';
        const s = document.getElementById('prodSearch'); s.value = ''; s.focus();
    }
    function filterProducts() {
        const t = document.getElementById('prodSearch').value.toUpperCase(); const l = document.getElementById('prodList'); l.innerHTML = '';
        defaultProducts.filter(p => p.includes(t)).forEach(p => { l.innerHTML += `<div style="padding:10px; border-bottom:1px solid #eee; cursor:pointer;" onclick="selectProd('${p}')">${p}</div>`; });
    }
    function selectProd(name) {
        if(isEditingMode) document.getElementById('editTmpProd').value = name; else document.getElementById('tmpProd').value = name;
        document.getElementById('modalProductSelect').style.display = 'none'; isEditingMode = false;
    }
    function addTmpItem() {
        const nf = document.getElementById('tmpNF').value; const prod = document.getElementById('tmpProd').value;
        if (nf && prod) { tmpItems.push({ nf, prod }); document.getElementById('tmpList').innerHTML += `<li><b>${nf}</b>: ${prod}</li>`; document.getElementById('tmpProd').value = ''; document.getElementById('tmpProd').focus(); }
    }
    function saveTruckAndMap() {
        const emp = document.getElementById('addEmpresa').value; const pla = document.getElementById('addPlaca').value;
        const dest = document.getElementById('addDestino').value; const balan = document.getElementById('chkBalan').checked; const laudo = document.getElementById('chkLaudo').checked;
        const secMap = { 'DOCA':{n:'DOCA (ALM)',c:'ALM'}, 'GAVA':{n:'GAVA',c:'GAVA'}, 'MANUTENCAO':{n:'MANUTENÇÃO',c:'OUT'}, 'INFRA':{n:'INFRAESTRUTURA',c:'OUT'}, 'PESAGEM':{n:'SALA DE PESAGEM',c:'OUT'}, 'LAB':{n:'LABORATÓRIO',c:'OUT'}, 'SST':{n:'SST',c:'OUT'}, 'CD':{n:'CD',c:'OUT'}, 'COMPRAS':{n:'COMPRAS',c:'OUT'} };
        const sec = secMap[dest] || {n:'OUTROS',c:'OUT'};
        if (!emp || tmpItems.length === 0 || !pla) { alert('Preencha campos.'); return; }
        const id = Date.now().toString(); const seq = patioData.filter(t => t.chegada.startsWith(today)).length + 1;
        patioData.push({ id, empresa: emp, local: sec.c, localSpec: sec.n, status: 'FILA', placa: pla.toUpperCase(), sequencia: seq, recebimentoNotified: false, saidaNotified: false, comLaudo: laudo, releasedBy: null, chegada: new Date().toISOString(), saida: null, cargas: [{ numero: '1', produtos: tmpItems.map(i => ({ nome: i.prod, qtd: '-', nf: i.nf })) }] });
        const rows = tmpItems.map((item, idx) => ({ id: id+'_'+idx, desc: item.prod, qty: '', qty_nf: '', nf: item.nf, forn: emp, owners: {} }));
        for(let i=rows.length; i<8; i++) rows.push({ id: id+'_x_'+i, desc: '', qty: '', qty_nf: '', nf: '', forn: '', owners: {} });
        mapData.push({ id, date: today, rows, placa: pla.toUpperCase(), setor: sec.n, launched: false, finishedNotified: false, signatures: {}, forceUnlock: false, divergence: null });
        if (balan) mpData.push({ id, date: today, produto: tmpItems[0].prod, empresa: emp, placa: pla.toUpperCase(), local: sec.n, chegada: new Date().toISOString(), tara:0, bruto:0, liq:0, pesoNF:0, difKg:0, difPerc:0, nf: tmpItems[0].nf, notes: '' });
        saveAll(); document.getElementById('modalTruck').style.display = 'none'; renderPatio(); alert(`Veículo #${seq} registrado!`);
    }

    function renderPatio() {
        const fd = document.getElementById('patioDateFilter').value;
        ['ALM','GAVA','OUT','SAIU'].forEach(c => { document.getElementById('list-'+c).innerHTML=''; if(c!=='SAIU') document.getElementById('count-'+c).textContent='0'; });
        const list = patioData.filter(c => {
            const cd = c.chegada.split('T')[0]; const isSaiu = c.status === 'SAIU';
            if (isSaiu && !c.saida.startsWith(fd)) return false;
            if (!isSaiu && cd !== fd) return false;
            if (isAdmin || isRecebimento) return true;
            if (isConferente && userSubType) {
                if (userSubType === 'ALM') return c.local === 'ALM' || c.local === 'GAVA';
                if (userSubType === 'GAVA') return c.local === 'GAVA';
                if (userSubType !== 'OUT') return c.localSpec && c.localSpec.toUpperCase().includes(userSubType);
                return c.local === 'OUT';
            }
            return true;
        }).sort((a,b)=>new Date(a.chegada)-new Date(b.chegada));

        list.forEach(c => {
            const isSaiu = c.status === 'SAIU'; let col = isSaiu ? 'SAIU' : (c.local || 'OUT');
            const cont = document.getElementById('list-'+col); if(!cont) return;
            if(!isSaiu) { const cn=document.getElementById('count-'+col); cn.textContent = parseInt(cn.textContent)+1; }
            
            const card = document.createElement('div'); card.className = 'truck-card';
            card.onclick = function(e){ if(e.target.tagName!=='BUTTON') this.classList.toggle('expanded'); };
            card.oncontextmenu = function(e){ e.preventDefault(); if(!isSaiu) openTruckContextMenu(e.pageX, e.pageY, c.id); };
            
            let stBad = '';
            if(c.status==='FILA') stBad='<div class="status-badge st-wait">Aguardando</div>';
            else if(c.status==='LIBERADO') stBad='<div class="status-badge st-called">Chamado</div>';
            else if(c.status==='ENTROU') stBad='<div class="status-badge st-ok">No Pátio</div>';
            else stBad='<div class="status-badge st-out">Finalizado</div>';

            let btn = '';
            if(!isSaiu) {
                if(c.status==='FILA') btn=`<button onclick="changeStatus('${c.id}','LIBERADO')" class="btn btn-save" style="width:100%; margin-top:5px;">CHAMAR</button>`;
                else if(c.status==='LIBERADO') btn=`<button onclick="changeStatus('${c.id}','ENTROU')" class="btn btn-launch" style="width:100%; margin-top:5px;">CONFIRMAR ENTRADA</button>`;
                else if(c.status==='ENTROU') btn=`<button onclick="changeStatus('${c.id}','SAIU')" class="btn btn-edit" style="width:100%; margin-top:5px;">REGISTRAR SAÍDA</button>`;
            }
            let prods = ''; if(c.cargas) c.cargas[0].produtos.forEach(p=>{ prods+=`<div style="display:flex; justify-content:space-between; font-size:0.8rem; margin-top:3px;"><span>${p.nome}</span><span>NF:${p.nf}</span></div>`; });

            card.innerHTML = `
            <div class="card-basic"><div><div class="card-company">${c.empresa} (#${c.sequencia})</div><small>${new Date(c.chegada).toLocaleTimeString().slice(0,5)} • ${c.placa}</small><div class="sector-tag">${c.localSpec}</div> ${c.comLaudo?'<span class="sector-tag" style="background:var(--primary)">LAUDO</span>':''}</div></div>
            ${stBad}
            <div class="card-expanded-content">${prods} ${btn}</div>`;
            cont.appendChild(card);
        });
    }
    function changeStatus(id, st) {
        const i = patioData.findIndex(c=>c.id===id); if(i>-1) {
            patioData[i].status = st;
            if(st==='LIBERADO') { patioData[i].releasedBy=loggedUser.username; patioData[i].recebimentoNotified=false; }
            if(st==='ENTROU') { const m=mpData.find(x=>x.id===id); if(m) m.entrada=new Date().toISOString(); }
            if(st==='SAIU') { const now=new Date().toISOString(); patioData[i].saida=now; const m=mpData.find(x=>x.id===id); if(m) m.saida=now; }
            saveAll(); renderPatio();
        }
    }

    function checkForNotifications() {
        const call = patioData.find(c => c.status==='LIBERADO' && !c.recebimentoNotified);
        if(call && isRecebimento) {
            showNotificationPopup('release', call);
            sendSystemNotification("Motorista Chamado!", `Setor: ${call.localSpec}\nPlaca: ${call.placa}`, 'patio', call.id);
        }
        const div = requests.find(r => r.type==='divergence' && r.target===loggedUser.username && r.status==='pending');
        if(div) {
            if(document.getElementById('modalNotification').style.display !== 'flex') {
                showNotificationPopup('divergence', div);
                sendSystemNotification("⚠️ DIVERGÊNCIA", `Motivo: ${div.msg}`, 'mapas', div.mapId);
            }
        }
        updateBadge();
    }
    setInterval(checkForNotifications, 4000);

    function showNotificationPopup(type, data) {
        const p = document.getElementById('notifPopupContent');
        document.getElementById('modalNotification').style.display = 'flex';
        if(type==='release') {
            p.innerHTML = `<h2 style="color:green">Liberado!</h2><p>${data.empresa} - ${data.placa}</p><button class="btn btn-save" onclick="confirmNotification('release','${data.id}')">OK</button>`;
        } else {
            p.innerHTML = `<h2 style="color:red">Divergência</h2><p>${data.msg}</p><button class="btn btn-edit" onclick="confirmNotification('divergence','${data.id}')">Ver</button>`;
        }
    }
    function confirmNotification(type, id) {
        if(type==='release') { const i=patioData.findIndex(c=>c.id===id); if(i>-1) patioData[i].recebimentoNotified=true; }
        else { const i=requests.findIndex(r=>r.id==id); if(i>-1) requests[i].status='seen'; navTo('mapas'); if(requests[i].mapId) loadMap(requests[i].mapId); }
        document.getElementById('modalNotification').style.display='none'; saveAll();
    }

    function renderMateriaPrima() {
        const tb = document.getElementById('mpBody'); tb.innerHTML = '';
        const d = document.getElementById('mpDateFilter').value;
        mpData.filter(m => m.date===d).forEach(m => {
            const tr = document.createElement('tr');
            tr.oncontextmenu = function(e){ e.preventDefault(); contextMPId=m.id; openMPContextMenu(e.pageX, e.pageY); };
            tr.innerHTML = `<td>${new Date(m.date).toLocaleDateString()}</td><td><b>${m.produto}</b><br><small>${m.empresa}</small></td><td>${m.placa}</td><td>${m.local}</td>
            <td>${m.chegada?m.chegada.slice(11,16):'-'}</td><td>${m.entrada?m.entrada.slice(11,16):'-'}</td>
            <td><input type="number" class="cell" style="width:70px" value="${m.tara}" onchange="updateWeights('${m.id}','tara',this.value)"></td>
            <td><input type="number" class="cell" style="width:70px" value="${m.bruto}" onchange="updateWeights('${m.id}','bruto',this.value)"></td>
            <td>${m.liq}</td><td><input type="number" class="cell" style="width:70px" value="${m.pesoNF}" onchange="updateWeights('${m.id}','pesoNF',this.value)"></td>
            <td>${m.difKg}</td><td>${m.difPerc}%</td><td>${m.saida?m.saida.slice(11,16):'-'}</td><td>${m.nf} ${m.notes?'<i class="fas fa-sticky-note"></i>':''}</td>`;
            tb.appendChild(tr);
        });
    }
    function updateWeights(id, f, v) {
        const i=mpData.findIndex(m=>m.id===id); if(i>-1) {
            mpData[i][f] = parseFloat(v)||0; mpData[i].liq = mpData[i].bruto - mpData[i].tara;
            mpData[i].difKg = mpData[i].liq - mpData[i].pesoNF; mpData[i].difPerc = mpData[i].pesoNF ? ((mpData[i].difKg/mpData[i].pesoNF)*100).toFixed(2) : 0;
            saveAll(); renderMateriaPrima();
        }
    }
    function openMPContextMenu(x,y){ const m=document.getElementById('ctxMenuMP'); m.innerHTML=`<div class="ctx-item" onclick="openEditMPModal()">Editar</div><div class="ctx-item" onclick="openNoteMPModal()">Observação</div>`; m.style.left=x+'px'; m.style.top=y+'px'; m.style.display='block'; }
    function openEditMPModal(){ const m=mpData.find(x=>x.id===contextMPId); document.getElementById('editMPId').value=m.id; document.getElementById('editMPEmpresa').value=m.empresa; document.getElementById('editMPPlaca').value=m.placa; document.getElementById('editMPProduto').value=m.produto; document.getElementById('modalEditMP').style.display='flex'; closeContextMenu(); }
    function saveEditMP(){ const id=document.getElementById('editMPId').value; const i=mpData.findIndex(x=>x.id===id); if(i>-1){ mpData[i].empresa=document.getElementById('editMPEmpresa').value; mpData[i].placa=document.getElementById('editMPPlaca').value; mpData[i].produto=document.getElementById('editMPProduto').value; saveAll(); renderMateriaPrima(); } document.getElementById('modalEditMP').style.display='none'; }
    function openNoteMPModal(){ const m=mpData.find(x=>x.id===contextMPId); document.getElementById('noteMPId').value=m.id; document.getElementById('noteMPText').value=m.notes||''; document.getElementById('modalNoteMP').style.display='flex'; closeContextMenu(); }
    function saveNoteMP(){ const id=document.getElementById('noteMPId').value; const i=mpData.findIndex(x=>x.id===id); if(i>-1){ mpData[i].notes=document.getElementById('noteMPText').value; saveAll(); renderMateriaPrima(); } document.getElementById('modalNoteMP').style.display='none'; }

    function renderCarregamento() {
        const tb = document.getElementById('carrBody'); tb.innerHTML = '';
        const d = document.getElementById('carrDateFilter').value;
        carregamentoData.filter(c => c.status!=='SAIU' || c.date===d).forEach(c => {
            const tr = document.createElement('tr');
            tr.oncontextmenu = function(e){ e.preventDefault(); contextCarrId=c.id; openCarrContextMenu(e.pageX, e.pageY); };
            let btn = c.status==='AGUARDANDO' ? `<button class="btn btn-save btn-small" onclick="changeStatusCarregamento('${c.id}','CARREGANDO')">LIBERAR</button>` : (c.status==='CARREGANDO' ? `<button class="btn btn-edit btn-small" onclick="changeStatusCarregamento('${c.id}','SAIU')">FINALIZAR</button>` : '-');
            tr.innerHTML = `<td>${c.status}</td><td>${c.motorista}</td><td>${c.cavalo}</td><td>${c.carretas.join(',')}</td><td><input class="cell" style="width:50px" value="${c.tara}" onchange="updateCarrWeight('${c.id}','tara',this.value)"></td><td><input class="cell" style="width:50px" value="${c.bruto}" onchange="updateCarrWeight('${c.id}','bruto',this.value)"></td><td>${c.liq}</td><td>${c.checkin.slice(11,16)}</td><td>${c.start?c.start.slice(11,16):'-'}</td><td>${c.checkout?c.checkout.slice(11,16):'-'}</td><td>${btn}</td>`;
            tb.appendChild(tr);
        });
    }
    function updateCarrWeight(id,f,v){ const i=carregamentoData.findIndex(c=>c.id===id); if(i>-1){ carregamentoData[i][f]=parseFloat(v)||0; carregamentoData[i].liq=carregamentoData[i].bruto-carregamentoData[i].tara; saveAll(); renderCarregamento(); } }
    function changeStatusCarregamento(id,s){ const i=carregamentoData.findIndex(c=>c.id===id); if(i>-1){ carregamentoData[i].status=s; if(s==='CARREGANDO') carregamentoData[i].start=new Date().toISOString(); if(s==='SAIU') carregamentoData[i].checkout=new Date().toISOString(); saveAll(); renderCarregamento(); } }
    function openModalCarregamento(){ document.getElementById('modalCarregamento').style.display='flex'; }
    function addCarretaField(){ document.getElementById('carretaContainer').innerHTML += `<input type="text" class="carrCarretaInput" style="width:100%; margin-top:5px;">`; }
    function saveCarregamento(){ const mot=document.getElementById('carrMotorista').value; const cav=document.getElementById('carrCavalo').value; const arr=[]; document.querySelectorAll('.carrCarretaInput').forEach(i=>{if(i.value)arr.push(i.value)}); carregamentoData.push({id:Date.now().toString(), date:today, motorista:mot, cavalo:cav, carretas:arr, tara:0, bruto:0, liq:0, status:'AGUARDANDO', checkin:new Date().toISOString()}); saveAll(); document.getElementById('modalCarregamento').style.display='none'; renderCarregamento(); }
    function openCarrContextMenu(x,y){ const m=document.getElementById('ctxMenuCarr'); m.innerHTML=`<div class="ctx-item" onclick="openEditCarrModal()">Editar</div><div class="ctx-item" onclick="openNoteCarrModal()">Nota</div><div class="ctx-item" style="color:red" onclick="deleteCarregamento()">Excluir</div>`; m.style.left=x+'px'; m.style.top=y+'px'; m.style.display='block'; }
    function openEditCarrModal(){ const c=carregamentoData.find(x=>x.id===contextCarrId); document.getElementById('editCarrId').value=c.id; document.getElementById('editCarrMot').value=c.motorista; document.getElementById('editCarrCav').value=c.cavalo; document.getElementById('modalEditCarr').style.display='flex'; closeContextMenu(); }
    function saveEditCarr(){ const id=document.getElementById('editCarrId').value; const i=carregamentoData.findIndex(x=>x.id===id); if(i>-1){ carregamentoData[i].motorista=document.getElementById('editCarrMot').value; carregamentoData[i].cavalo=document.getElementById('editCarrCav').value; saveAll(); renderCarregamento(); } document.getElementById('modalEditCarr').style.display='none'; }
    function deleteCarregamento(){ if(confirm('Excluir?')) { carregamentoData=carregamentoData.filter(x=>x.id!==contextCarrId); saveAll(); renderCarregamento(); } closeContextMenu(); }
    function openNoteCarrModal(){ const c=carregamentoData.find(x=>x.id===contextCarrId); document.getElementById('noteCarrId').value=c.id; document.getElementById('noteCarrText').value=c.notes||''; document.getElementById('modalNoteCarr').style.display='flex'; closeContextMenu(); }
    function saveNoteCarr(){ const id=document.getElementById('noteCarrId').value; const i=carregamentoData.findIndex(x=>x.id===id); if(i>-1){ carregamentoData[i].notes=document.getElementById('noteCarrText').value; saveAll(); renderCarregamento(); } document.getElementById('modalNoteCarr').style.display='none'; }

    function renderMapList() {
        const fd = document.getElementById('mapListDateFilter').value;
        const l = document.getElementById('mapList'); l.innerHTML = '';
        
        const filteredMaps = mapData.filter(m => {
            if (m.date !== fd) return false;
            if (isAdmin || isRecebimento) return true;
            if (isConferente) {
                const mapSetor = (m.setor || '').toUpperCase();
                if (userSubType === 'ALM') return mapSetor.includes('ALM') || mapSetor.includes('DOCA') || mapSetor.includes('GAVA');
                if (userSubType === 'GAVA') return mapSetor.includes('GAVA');
                const sectorNames = { 'INFRA': 'INFRAESTRUTURA', 'MANUT': 'MANUTENÇÃO', 'LAB': 'LABORATÓRIO', 'PESAGEM': 'PESAGEM', 'SST': 'SST', 'CD': 'CD', 'COMPRAS': 'COMPRAS' };
                const mySectorName = sectorNames[userSubType] || userSubType;
                return mapSetor.includes(mySectorName);
            }
            return true;
        }).slice().reverse();

        filteredMaps.forEach(m => {
            const forn = m.rows.find(r=>r.forn)?.forn || 'Diversos'; 
            const el = document.createElement('div'); el.className = `mc-item ${currentMapId===m.id?'selected':''}`; if(m.divergence) el.style.borderLeft="4px solid red";
            el.innerHTML = `<div><b>${forn}</b></div><small>${m.placa} • ${m.setor}</small><div>${m.launched?'Lançado':'Rascunho'} ${m.divergence?'<b style="color:red">(DIV)</b>':''}</div>`;
            el.onclick = () => { loadMap(m.id); if(window.innerWidth<=1024) toggleMapListMobile(); };
            el.oncontextmenu = function(e){ e.preventDefault(); contextMapId=m.id; openContextMenu(e.pageX,e.pageY,m); };
            l.appendChild(el);
        });
    }

    function openContextMenu(x,y,m){ 
        const menu = document.getElementById('ctxMenu'); 
        let html = `<div class="ctx-item" style="color:red" onclick="openDivergenceModal('${m.id}')">Divergência</div>`;
        if(isConferente) html += `<div class="ctx-item" onclick="triggerRequest('edit','${m.id}')">Solicitar Edição</div>`;
        else html += `<div class="ctx-item" onclick="forceUnlockMap('${m.id}')">Forçar Edição</div><div class="ctx-item" style="color:red" onclick="deleteMap('${m.id}')">Excluir</div>`;
        menu.innerHTML = html; menu.style.left=x+'px'; menu.style.top=y+'px'; menu.style.display='block';
    }
    function loadMap(id) {
        currentMapId = id; const m = mapData.find(x=>x.id===id); if(!m) return;
        document.getElementById('mapDate').value = m.date; document.getElementById('mapPlaca').value = m.placa; document.getElementById('mapSetor').value = m.setor;
        const b = document.getElementById('divBanner');
        if(m.divergence) { b.style.display='block'; document.getElementById('divBannerText').innerHTML = `De: ${m.divergence.reporter}<br>"${m.divergence.reason}"`; document.getElementById('divResolveBtn').innerHTML = isRecebimento ? `<button class="btn btn-save" onclick="resolveDivergence('${m.id}')">Resolver</button>` : ''; }
        else b.style.display='none';
        const st = document.getElementById('mapStatus');
        if(m.launched && !m.forceUnlock) { st.textContent='LANÇADO (Bloqueado)'; st.style.color='green'; document.getElementById('btnLaunch').style.display='none'; document.getElementById('btnRequestEdit').style.display = isConferente?'inline-block':'none'; }
        else { st.textContent=m.forceUnlock?'EM EDIÇÃO (Desbloqueado)':'Rascunho'; st.style.color=m.forceUnlock?'orange':'#666'; document.getElementById('btnLaunch').style.display='inline-block'; document.getElementById('btnRequestEdit').style.display='none'; }
        document.getElementById('sigReceb').textContent=m.signatures.receb||''; document.getElementById('sigConf').textContent=m.signatures.conf||'';
        renderRows(m); renderMapList();
    }
    function renderRows(m) {
        const tb = document.getElementById('mapBody'); tb.innerHTML='';
        const locked = m.launched && !m.forceUnlock;
        m.rows.forEach(r => {
            const tr = document.createElement('tr');
            const createCell = (f, role) => {
                let ro = locked; if(!locked) { if(role==='conf' && !isConferente) ro=true; if(role==='receb' && !isRecebimento) ro=true; }
                let val = r[f]; if(isConferente && f==='qty_nf') { val='---'; ro=true; }
                return `<td><input type="text" class="cell" value="${val}" ${ro?'readonly':''} onchange="updateRow('${r.id}','${f}',this.value)" style="width:100%"></td>`;
            };
            tr.innerHTML = `${createCell('desc','receb')} ${createCell('qty_nf','receb')} ${createCell('qty','conf')} ${createCell('nf','receb')} ${createCell('forn','receb')}`;
            tb.appendChild(tr);
        });
    }
    function updateRow(rid, f, v){ const m=mapData.find(x=>x.id===currentMapId); const r=m.rows.find(x=>x.id===rid); if(r){ r[f]=v; saveAll(); } }
    function saveCurrentMap(){ const m=mapData.find(x=>x.id===currentMapId); if(m){ m.date=document.getElementById('mapDate').value; m.placa=document.getElementById('mapPlaca').value; m.setor=document.getElementById('mapSetor').value; saveAll(); alert('Salvo.'); renderMapList(); } }
    function launchMap(){ const m=mapData.find(x=>x.id===currentMapId); if(!m.signatures.receb || !m.signatures.conf) { alert('Assinaturas obrigatórias.'); return; } if(confirm('Lançar?')){ m.launched=true; m.forceUnlock=false; saveAll(); loadMap(currentMapId); } }
    function signMap(role){ const m=mapData.find(x=>x.id===currentMapId); if(!m) return; if(role==='receb' && !isRecebimento) return alert('Só Recebimento'); if(role==='conf' && !isConferente) return alert('Só Conferente'); m.signatures[role]=loggedUser.username+' '+new Date().toLocaleTimeString().slice(0,5); saveAll(); loadMap(currentMapId); }
    function createNewMap(){ const id=Date.now().toString(); const rows=[]; for(let i=0;i<8;i++) rows.push({id:id+'_'+i, desc:'', qty:'', nf:'', forn:'', owners:{}}); mapData.push({id, date:today, rows, placa:'', setor:'', launched:false, signatures:{}, divergence:null}); saveAll(); renderMapList(); loadMap(id); }
    function forceUnlockMap(id){ const m=mapData.find(x=>x.id===id); if(m){ m.forceUnlock=true; saveAll(); loadMap(id); closeContextMenu(); } }
    function deleteMap(id){ if(confirm('Excluir Mapa?')){ mapData=mapData.filter(x=>x.id!==id); saveAll(); renderMapList(); document.getElementById('mapBody').innerHTML=''; closeContextMenu(); } }

    function openDivergenceModal(id){ contextMapId=id; document.getElementById('divUserList').innerHTML = ['Caio','Balanca','Fabricio','Admin'].map(u=>`<label style="display:block"><input type="checkbox" value="${u}"> ${u}</label>`).join(''); document.getElementById('divReason').value=''; document.getElementById('modalDivergence').style.display='flex'; closeContextMenu(); }
    function submitDivergence(){ const m=mapData.find(x=>x.id===contextMapId); if(m){ m.divergence={ active:true, reason:document.getElementById('divReason').value, reporter:loggedUser.username }; const t=Array.from(document.querySelectorAll('#divUserList input:checked')).map(x=>x.value); t.forEach(u=>requests.push({ id:Date.now()+Math.random(), type:'divergence', user:loggedUser.username, target:u, mapId:contextMapId, msg:m.divergence.reason, status:'pending' })); saveAll(); document.getElementById('modalDivergence').style.display='none'; loadMap(contextMapId); } }
    function resolveDivergence(id){ if(confirm('Resolver?')){ const m=mapData.find(x=>x.id===id); if(m){ m.divergence=null; saveAll(); loadMap(id); } } }
    function triggerRequest(type, mid){ const t=mid||currentMapId; const u=prompt('Para quem?'); const r=prompt('Motivo'); if(u && r){ requests.push({ id:Date.now(), mapId:t, user:loggedUser.username, target:u, type, msg:r, status:'pending' }); saveAll(); closeContextMenu(); alert('Solicitado'); } }
    function renderRequests(){ const l=document.getElementById('reqList'); l.innerHTML=''; const h=document.getElementById('historyList'); h.innerHTML=''; requests.filter(r=>r.status==='pending' && (r.target===loggedUser.username || r.type!=='divergence')).forEach(r=>{ l.innerHTML+=`<div style="margin-bottom:5px; padding:10px; border:1px solid #eee;"><b>${r.type}</b>: ${r.msg} <button onclick="resolveRequest(${r.id},'approved')">Aceitar</button></div>`; }); requests.slice(0,10).forEach(r=>{ h.innerHTML+=`<div style="font-size:0.8rem; border-bottom:1px solid #eee; padding:5px;">${r.type} ${r.status}</div>`; }); updateBadge(); }
    function resolveRequest(id, st){ const i=requests.findIndex(r=>r.id===id); if(i>-1){ requests[i].status=st; if(st==='approved' && requests[i].type==='edit'){ const m=mapData.find(x=>x.id===requests[i].mapId); if(m) m.forceUnlock=true; } saveAll(); renderRequests(); } }
    function updateBadge(){ const c=requests.filter(r=>r.status==='pending' && r.target===loggedUser.username).length; const b=document.getElementById('badgeNotif'); if(c>0){ b.innerText=c; b.style.display='inline-block'; } else b.style.display='none'; }

    function openTruckContextMenu(x,y,id){ if(!isRecebimento) return; contextTruckId=id; const m=document.getElementById('ctxMenuTruck'); m.innerHTML=`<div class="ctx-item" onclick="openEditTruck('${id}')">Editar Veículo</div>`; m.style.left=x+'px'; m.style.top=y+'px'; m.style.display='block'; }
    function openEditTruck(id){
        const t=patioData.find(x=>x.id===id); if(!t) return;
        document.getElementById('editTruckId').value=id; document.getElementById('editTruckPlaca').value=t.placa; document.getElementById('editTruckLaudo').checked=t.comLaudo;
        const sel=document.getElementById('editTruckDestino'); for(let i=0;i<sel.options.length;i++) if(t.localSpec && sel.options[i].text.includes(t.localSpec)) sel.selectedIndex=i;
        editTmpItems = t.cargas[0].produtos.map(p=>({nf:p.nf, prod:p.nome})); renderEditTmpList();
        document.getElementById('modalEditTruck').style.display='flex'; closeContextMenu();
    }
    function renderEditTmpList(){ const l=document.getElementById('editTmpList'); l.innerHTML=''; editTmpItems.forEach((x,i)=>{ l.innerHTML+=`<li style="display:flex; justify-content:space-between; margin-bottom:5px;">${x.prod} (${x.nf}) <button onclick="removeEditTmpItem(${i})" style="color:red; border:none; background:none;">X</button></li>`; }); }
    function addEditTmpItem(){ const nf=document.getElementById('editTmpNF').value; const prod=document.getElementById('editTmpProd').value; if(nf&&prod){ editTmpItems.push({nf,prod}); renderEditTmpList(); } }
    function removeEditTmpItem(i){ editTmpItems.splice(i,1); renderEditTmpList(); }
    function openProdSelectForEdit(){ isEditingMode=true; openProdSelect(); }
    function saveEditTruck(){
        const id=document.getElementById('editTruckId').value; const i=patioData.findIndex(x=>x.id===id);
        if(i>-1){
            patioData[i].placa=document.getElementById('editTruckPlaca').value.toUpperCase();
            patioData[i].comLaudo=document.getElementById('editTruckLaudo').checked;
            const destKey=document.getElementById('editTruckDestino').value;
            const secMap = { 'DOCA':{n:'DOCA (ALM)',c:'ALM'}, 'GAVA':{n:'GAVA',c:'GAVA'}, 'MANUTENCAO':{n:'MANUTENÇÃO',c:'OUT'}, 'INFRA':{n:'INFRAESTRUTURA',c:'OUT'}, 'PESAGEM':{n:'SALA DE PESAGEM',c:'OUT'}, 'LAB':{n:'LABORATÓRIO',c:'OUT'}, 'SST':{n:'SST',c:'OUT'}, 'CD':{n:'CD',c:'OUT'}, 'COMPRAS':{n:'COMPRAS',c:'OUT'} };
            const sec = secMap[destKey] || {n:'OUTROS',c:'OUT'};
            patioData[i].local=sec.c; patioData[i].localSpec=sec.n;
            patioData[i].cargas[0].produtos=editTmpItems.map(x=>({nome:x.prod, qtd:'-', nf:x.nf}));
            const m=mapData.find(x=>x.id===id); if(m){ m.placa=patioData[i].placa; m.setor=sec.n; if(!m.launched){ const rows=editTmpItems.map((it,ix)=>({id:id+'_'+ix, desc:it.prod, qty:'', nf:it.nf, forn:m.rows[0].forn, owners:{}})); for(let k=rows.length; k<8; k++) rows.push({id:id+'_x_'+k, desc:'', qty:'', nf:'', forn:'', owners:{}}); m.rows=rows; } }
            const mp=mpData.find(x=>x.id===id); if(mp){ mp.placa=patioData[i].placa; mp.local=sec.n; if(editTmpItems[0]){ mp.produto=editTmpItems[0].prod; mp.nf=editTmpItems[0].nf; } }
            saveAll(); renderPatio(); document.getElementById('modalEditTruck').style.display='none';
        }
    }
    function deleteTruck(){ 
        const id=document.getElementById('editTruckId').value;
        if(confirm('ATENÇÃO: Isso apaga o registro do pátio, mapa cego e pesagem. Confirmar?')){
            patioData=patioData.filter(x=>x.id!==id); mapData=mapData.filter(x=>x.id!==id); mpData=mpData.filter(x=>x.id!==id);
            saveAll(); renderPatio(); document.getElementById('modalEditTruck').style.display='none';
        }
    }

    function toggleReportSelection(id) {
        if (selectedReportItems.has(id)) selectedReportItems.delete(id);
        else selectedReportItems.add(id);
    }

    function toggleDivergenceGroup(fornId) {
        const rows = document.querySelectorAll(`.div-group-${fornId}`);
        rows.forEach(r => {
            if(r.classList.contains('hidden-row')) r.classList.remove('hidden-row');
            else r.classList.add('hidden-row');
        });
    }

    function generateAdvancedReport() {
        const t=document.getElementById('repType').value; const s=document.getElementById('repDateStart').value; const e=document.getElementById('repDateEnd').value; const term=document.getElementById('repSearchTerm').value.toUpperCase();
        const area=document.getElementById('repResultArea');
        currentReportType=t;
        selectedReportItems.clear(); // Resetar seleção

        let data=[];
        if(t==='patio') data=patioData; else if(t==='mapas') data=mapData; else if(t==='carregamento') data=carregamentoData; else if(t==='materia-prima') data=mpData;
        
        // --- RELATÓRIO DE DIVERGÊNCIAS (AGRUPADO) ---
        if(t==='divergencias') {
            filteredReportData = []; // Para exportação (flat)
            const maps = mapData.filter(x => x.date >= s && x.date <= e);
            const groups = {}; // { 'Fornecedor X': [ {prod...}, {prod...} ] }
            
            maps.forEach(m => {
                m.rows.forEach(r => {
                    const qnf=parseFloat(r.qty_nf)||0; const qc=parseFloat(r.qty)||0; const diff=qc-qnf;
                    if (diff !== 0 && !isNaN(qnf) && !isNaN(qc)) {
                        if (!term || (r.desc.toUpperCase().includes(term) || r.forn.toUpperCase().includes(term))) {
                            const fornName = r.forn || 'SEM FORNECEDOR';
                            if(!groups[fornName]) groups[fornName] = [];
                            const itemObj = {
                                id: m.id + '_' + r.id, mapId: m.id, date: m.date, forn: fornName, 
                                prod: r.desc, nf: r.nf, diff: diff, qnf: qnf, qc: qc
                            };
                            groups[fornName].push(itemObj);
                            filteredReportData.push(itemObj);
                        }
                    }
                });
            });

            let html = '<table class="modern-table"><thead><tr><th style="width:40px">#</th><th>Fornecedor</th><th>Qtd. Itens com Divergência</th></tr></thead><tbody>';
            if (Object.keys(groups).length === 0) {
                area.innerHTML = '<p style="text-align:center; padding:20px; color:#666;">Nenhuma divergência encontrada no período.</p>';
                document.getElementById('repTotalCount').innerText = 0; document.getElementById('repFooter').style.display='none'; return;
            }

            let groupIdCounter = 0;
            for (const [forn, items] of Object.entries(groups)) {
                groupIdCounter++;
                const groupId = 'g' + groupIdCounter;
                html += `<tr class="group-row" onclick="toggleDivergenceGroup('${groupId}')"><td><i class="fas fa-chevron-right" style="font-size:0.8rem"></i></td><td>${forn}</td><td>${items.length} produto(s)</td></tr>`;
                items.forEach(item => {
                    const diffColor = item.diff > 0 ? 'green' : 'red'; const diffSignal = item.diff > 0 ? '+' : '';
                    html += `<tr class="detail-row div-group-${groupId} hidden-row interactive-row" onclick="openReportDetails('${item.id}', 'divergencias-single')"><td><input type="checkbox" class="rep-check" onclick="event.stopPropagation(); toggleReportSelection('${item.id}')"></td><td colspan="2" style="padding-left:40px;"><div style="display:flex; justify-content:space-between; align-items:center;"><div><b>${item.prod}</b> <small>(NF: ${item.nf})</small></div><div style="font-weight:bold; color:${diffColor}">${diffSignal}${item.diff}</div></div></td></tr>`;
                });
            }
            html += '</tbody></table>'; area.innerHTML = html; document.getElementById('repTotalCount').innerText = filteredReportData.length; document.getElementById('repFooter').style.display='block'; return;
        }

        filteredReportData = data.filter(i => {
            const d = i.chegada || i.date || i.checkin; if(!d) return false;
            const ds = d.slice(0,10);
            if(ds<s || ds>e) return false;
            if(term) { return JSON.stringify(i).toUpperCase().includes(term); }
            return true;
        });

        let html='<table class="modern-table"><thead><tr><th style="width:40px;">#</th>';
        if(t==='patio') html+='<th>Data</th><th>Empresa</th><th>Placa</th><th>Status</th>';
        else if(t==='mapas') html+='<th>Data</th><th>Placa</th><th>Fornecedor</th><th>Status</th>';
        else if(t==='materia-prima') html+='<th>Data</th><th>Produto</th><th>Placa</th><th>Líquido</th>';
        else html+='<th>Data</th><th>Motorista</th><th>Status</th>';
        html+='</tr></thead><tbody>';
        
        filteredReportData.forEach((i, idx)=>{
            html+=`<tr onclick="openReportDetails(${idx}, '${t}')" class="interactive-row">`;
            html+=`<td><input type="checkbox" class="rep-check" onclick="event.stopPropagation(); toggleReportSelection('${i.id}')"></td>`;
            if(t==='patio') html+=`<td>${new Date(i.chegada).toLocaleString()}</td><td>${i.empresa}</td><td>${i.placa}</td><td>${i.status}</td>`;
            else if(t==='mapas') html+=`<td>${i.date}</td><td>${i.placa}</td><td>${i.rows[0]?.forn}</td><td>${i.launched?'Lançado':'Rascunho'}</td>`;
            else if(t==='materia-prima') html+=`<td>${new Date(i.date).toLocaleDateString()}</td><td>${i.produto}</td><td>${i.placa}</td><td>${i.liq} Kg</td>`;
            else html+=`<td>${new Date(i.checkin).toLocaleString()}</td><td>${i.motorista}</td><td>${i.status}</td>`;
            html+='</tr>';
        });
        html+='</tbody></table>';
        area.innerHTML = html;
        document.getElementById('repTotalCount').innerText = filteredReportData.length;
        document.getElementById('repFooter').style.display='block';
    }

    function openReportDetails(indexOrId, type) {
        let item;
        if (type === 'divergencias-single') { item = filteredReportData.find(x => x.id === indexOrId); type = 'divergencias'; } else { item = filteredReportData[indexOrId]; }
        if (!item) return;

        const modal = document.getElementById('modalReportDetail');
        const content = document.getElementById('repDetailContent');
        const actions = document.getElementById('repDetailActions');
        let html = ''; let btnMap = '';

        if (type === 'mapas') {
            html = `<h4>Mapa Cego #${item.id}</h4><p><b>Data:</b> ${item.date}</p><p><b>Placa:</b> ${item.placa}</p><p><b>Setor:</b> ${item.setor}</p><hr>`;
            item.rows.forEach(r => { if(r.desc) html += `<div style="border-bottom:1px solid #eee; padding:5px;"><b>${r.desc}</b> (NF:${r.nf}) - Qtd: ${r.qty}</div>`; });
            btnMap = `<button class="btn btn-save" onclick="document.getElementById('modalReportDetail').style.display='none'; navTo('mapas'); loadMap('${item.id}')">ABRIR MAPA CEGO</button>`;
        } else if (type === 'divergencias') {
            const diffColor = item.diff > 0 ? 'green' : 'red';
            html = `<h4>Detalhe da Divergência</h4><p><b>Fornecedor:</b> ${item.forn}</p><p><b>Produto:</b> ${item.prod}</p><p><b>Nota Fiscal:</b> ${item.nf}</p><div style="background:#f9f9f9; padding:10px; border-radius:6px; margin-top:10px;"><p>Quantidade na Nota: <b>${item.qnf}</b></p><p>Quantidade Contada: <b>${item.qc}</b></p><h3 style="color:${diffColor}; margin:5px 0;">Diferença: ${item.diff > 0 ? '+' : ''}${item.diff}</h3></div>`;
            btnMap = `<button class="btn btn-save" onclick="document.getElementById('modalReportDetail').style.display='none'; navTo('mapas'); loadMap('${item.mapId}')">CORRIGIR NO MAPA</button>`;
        } else if (type === 'patio') {
            html = `<h4>Veículo: ${item.placa}</h4><p><b>Empresa:</b> ${item.empresa}</p><p><b>Chegada:</b> ${new Date(item.chegada).toLocaleString()}</p><p><b>Status:</b> ${item.status}</p><hr>`;
            if(item.cargas) item.cargas[0].produtos.forEach(p => { html += `<div>${p.nome} (NF: ${p.nf})</div>`; });
        } else if (type === 'materia-prima') {
            html = `<h4>Pesagem: ${item.placa}</h4><p><b>Produto:</b> ${item.produto}</p><p><b>Empresa:</b> ${item.empresa}</p><p><b>Nota Fiscal:</b> ${item.nf}</p><hr><div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;"><div>Tara: <b>${item.tara}</b></div><div>Bruto: <b>${item.bruto}</b></div><div>Líquido: <b>${item.liq}</b></div><div>Peso NF: <b>${item.pesoNF}</b></div></div><p style="margin-top:10px; font-weight:bold; color:${item.difKg!==0?'red':'green'}">Diferença: ${item.difKg} kg (${item.difPerc}%)</p>`;
        }
        content.innerHTML = html;
        actions.innerHTML = btnMap + `<button class="btn btn-edit" onclick="document.getElementById('modalReportDetail').style.display='none'" style="margin-left:10px;">Fechar</button>`;
        modal.style.display = 'flex';
    }

    function exportReportToPDF() {
        if(filteredReportData.length===0) return alert('Gere o relatório primeiro.');
        let dataToPrint = filteredReportData;
        if (selectedReportItems.size > 0) { dataToPrint = filteredReportData.filter(i => selectedReportItems.has(i.id)); }
        const { jsPDF } = window.jspdf;
        
        if(currentReportType==='mapas'){
            const doc = new jsPDF({ orientation: 'portrait' }); let y = 10;
            dataToPrint.forEach((m, i) => { if (i > 0 && i % 2 === 0) { doc.addPage(); y = 10; } drawSheetVisual(doc, m, 10, y); y += 145; });
            doc.save('Mapas_Cegos.pdf');
        } else if(currentReportType==='divergencias') {
            const doc = new jsPDF({ orientation: 'portrait' }); doc.setFontSize(16); doc.text("Relatório de Divergências", 10, 15); doc.setFontSize(10); let y = 25;
            dataToPrint.forEach(d => {
                if(y > 270) { doc.addPage(); y = 20; }
                doc.setFillColor(245,245,245); doc.rect(10, y, 190, 20, 'F');
                doc.text(`${d.date} | ${d.forn}`, 15, y+5);
                doc.setFont("helvetica", "bold"); doc.text(`PRODUTO: ${d.prod} (NF: ${d.nf})`, 15, y+12); doc.text(`DIFERENÇA: ${d.diff}`, 150, y+12); doc.setFont("helvetica", "normal"); y += 25;
            });
            doc.save('Divergencias.pdf');
        } else {
            const doc = new jsPDF({ orientation: 'landscape' }); doc.text("Relatório - " + currentReportType.toUpperCase(), 10, 10); let y=20;
            dataToPrint.forEach(i=>{
                if(y>190) { doc.addPage(); y=20; }
                let line = "";
                if(currentReportType==='patio') line = `${i.chegada.slice(0,16)} | ${i.empresa} | ${i.placa} | ${i.status}`;
                else if(currentReportType==='materia-prima') line = `${i.date} | ${i.produto} | ${i.placa} | Liq: ${i.liq}`;
                else if(currentReportType==='carregamento') line = `${i.checkin.slice(0,16)} | ${i.motorista} | ${i.cavalo} | ${i.status}`;
                doc.text(line, 10, y); y+=7;
            });
            doc.save('Relatorio_Geral.pdf');
        }
    }

    function drawSheetVisual(doc, m, x, y) {
        const w = 190; const h = 135; 
        doc.setDrawColor(100); doc.setFillColor(255,255,255); doc.rect(x, y, w, h, 'FD'); 
        doc.addImage('https://www.alimentoswilson.com.br/imgs/logo-wilson.png', 'PNG', x+5, y+5, 20, 10); 
        doc.setFontSize(12); doc.setFont("helvetica", "bold"); doc.text("RECEBIMENTO DIÁRIO - MAPA CEGO", x+30, y+12);
        doc.setFontSize(10); doc.setFont("helvetica", "normal"); doc.text(`Data: ${m.date}`, x+150, y+12);
        let ty = y + 20; doc.setFillColor(50,50,50); doc.rect(x+5, ty, w-10, 8, 'F'); doc.setTextColor(255); doc.setFontSize(8);
        doc.text("DESCRIÇÃO", x+7, ty+5); doc.text("QTD NF", x+80, ty+5); doc.text("QTD CONT", x+100, ty+5); doc.text("NF", x+120, ty+5); doc.text("FORNECEDOR", x+145, ty+5); doc.setTextColor(0);
        ty += 8;
        for(let i=0; i<6; i++) {
            const r = m.rows[i] || {}; doc.rect(x+5, ty, w-10, 8); 
            if(r.desc) { doc.text(r.desc.substring(0,40), x+7, ty+5); doc.text(r.qty_nf.toString(), x+80, ty+5); doc.text(r.qty.toString(), x+100, ty+5); doc.text(r.nf.toString(), x+120, ty+5); doc.text(r.forn.substring(0,15), x+145, ty+5); }
            ty += 8;
        }
        let fy = y + 100; doc.setFont("helvetica", "bold"); doc.text(`Setor: ${m.setor}`, x+10, fy); doc.text(`Placa: ${m.placa}`, x+10, fy+10);
        doc.rect(x+80, fy-5, 100, 20); doc.setFontSize(7); doc.text("ASS. RECEBIMENTO", x+82, fy); doc.text(m.signatures.receb || "__________________", x+82, fy+10); doc.text("ASS. CONFERENTE", x+135, fy); doc.text(m.signatures.conf || "__________________", x+135, fy+10);
    }

    function toggleDarkMode(){ const c=document.getElementById('darkModeToggle').checked; if(c) document.body.classList.add('dark-mode'); else document.body.classList.remove('dark-mode'); localStorage.setItem('aw_dark_mode',c); }
    function backupData(){ const d={patio:patioData, mapas:mapData, mp:mpData, carr:carregamentoData, req:requests}; const a=document.createElement('a'); a.href='data:text/json;charset=utf-8,'+encodeURIComponent(JSON.stringify(d)); a.download='backup.json'; a.click(); }
    function restoreData(i){ const f=i.files[0]; const r=new FileReader(); r.onload=e=>{ const d=JSON.parse(e.target.result); if(confirm('Restaurar?')){ if(d.patio) localStorage.setItem('aw_caminhoes_v2',JSON.stringify(d.patio)); if(d.mapas) localStorage.setItem('mapas_cegos_v3',JSON.stringify(d.mapas)); if(d.mp) localStorage.setItem('aw_materia_prima',JSON.stringify(d.mp)); if(d.carr) localStorage.setItem('aw_carregamento',JSON.stringify(d.carr)); window.location.reload(); } }; r.readAsText(f); }
    function clearAllData(){ if(confirm('Apagar TUDO?')){ localStorage.clear(); window.location.reload(); } }
    function closeContextMenu(){ document.querySelectorAll('.context-menu').forEach(x=>x.style.display='none'); }
    function saveAll(){ localStorage.setItem('aw_caminhoes_v2',JSON.stringify(patioData)); localStorage.setItem('mapas_cegos_v3',JSON.stringify(mapData)); localStorage.setItem('aw_materia_prima',JSON.stringify(mpData)); localStorage.setItem('aw_carregamento',JSON.stringify(carregamentoData)); localStorage.setItem('aw_requests',JSON.stringify(requests)); }

    initRoleBasedUI();
    const lastView = localStorage.getItem('aw_last_view') || 'patio';
    if(loggedUser) navTo(lastView);

    // ==========================================================================
// 10. SINCRONIZAÇÃO ENTRE ABAS (REAL-TIME LOCAL)
// ==========================================================================

window.addEventListener('storage', function(e) {
    // 1. Recarrega todos os dados do LocalStorage
    patioData = JSON.parse(localStorage.getItem('aw_caminhoes_v2')) || [];
    mapData = JSON.parse(localStorage.getItem('mapas_cegos_v3')) || [];
    mpData = JSON.parse(localStorage.getItem('aw_materia_prima')) || [];
    carregamentoData = JSON.parse(localStorage.getItem('aw_carregamento')) || [];
    requests = JSON.parse(localStorage.getItem('aw_requests')) || [];
    usersData = JSON.parse(localStorage.getItem('mapa_cego_users')) || [];

    // 2. Identifica qual tela o usuário está vendo agora
    const activeSection = document.querySelector('.view-section.active');
    if (!activeSection) return;
    const currentView = activeSection.id.replace('view-', '');

    // 3. Atualiza a interface da tela atual imediatamente
    if (currentView === 'patio') renderPatio();
    if (currentView === 'mapas') {
        renderMapList();
        // Se estiver com um mapa aberto, recarrega ele para ver edições em tempo real
        if (currentMapId) {
            const mapStillExists = mapData.find(m => m.id === currentMapId);
            if (mapStillExists) loadMap(currentMapId);
            else document.getElementById('mapBody').innerHTML = ''; // Mapa foi excluído
        }
    }
    if (currentView === 'materia-prima') renderMateriaPrima();
    if (currentView === 'carregamento') renderCarregamento();
    if (currentView === 'notificacoes') renderRequests();
    if (currentView === 'perfil' && isAdmin) renderUserList();

    // 4. Atualiza notificações globais (Badge e popups)
    updateBadge();
    
    // Opcional: Verifica se há novas notificações críticas para disparar som
    // (Apenas se não for a aba que originou a ação)
    const newDiv = requests.find(r => r.type === 'divergence' && r.target === loggedUser.username && r.status === 'pending');
    if (newDiv) {
        playBeep();
        // Se quiser popup visual:
        // showNotificationPopup('divergence', newDiv);
    }
});